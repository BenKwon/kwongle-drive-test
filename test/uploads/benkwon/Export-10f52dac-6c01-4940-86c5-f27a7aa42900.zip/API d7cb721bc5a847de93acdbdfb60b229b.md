# API

- Auth
    
    
    |  | 메서드 | EndPoint |
    | --- | --- | --- |
    | Login(로그인) | POST | api/auth/login |
    | Register(회원가입) | POST | api/auth/register |
    1. Login
        - EndPoint: [POST] api/auth/login
        - Description: username과 password로 로그인합니다. token을 return합니다.
        
        **Request Example**
        
        ```jsx
        {
        	"username": "Test"
        	"password": "Password1"
        }
        ```
        
        **Response Example**
        
        ```jsx
        {
        	"success": true,
        	"message": null,
        	"erros": null,
        	"token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJfaWQiOiI1OThkZGI2MzIyYWMxMDExZTA"
        }
        ```
        
    2. Register
        - EndPoint: [POST] api/auth/register
        - Description: username과 password, email로 가입을 시도합니다.
        
        **Request Example**
        
        ```jsx
        {
        	"username": "Test"
        	"password": "Password1"
        	"email": "email@test.com"
        }
        ```
        
        **Response Example**
        
        성공시
        
        ```jsx
        {
        	"success": true,
        	"message": null,
        	"erros": null,
        }
        ```
        
        실패시
        
        ```jsx
        {
        	"success": null,
        	"message": "username혹은 eamil이 이미 존재합니다.",
        	"erros": true,
        }
        ```
        
- Drive (http://hostname:port/drive)
    
    
    |  | 메서드 | 엔드포인트 | 구현 테스트 여부 |
    | --- | --- | --- | --- |
    | 1. Path내 파일 및 폴더 구조 정보 가져오기 | GET | drive/folders/:path | ? |
    | 2. 파일 업로드 | POST | drive/upload | multer |
    | 3. 파일 다운로드 | GET |  | ? |
    | 4. 디렉토리 생성 | POST |  | ? |
    | 5. 파일/디렉토리 삭제 | DELETE |  | ? |
    | 6.파일/ 폴더명 변경 | PUT |  | ? |
    | 7. 이미지 프리뷰 다운로드 | GET |  | ? |
    | 8. 비디오 스트리밍  | GET |  | ? |
    1. Path내 파일 및 폴더 구조 정보 가져오기
        - EndPoint: [GET] drive/folders/:path
        - Description: ${path} 경로 내에 있는 폴더와 파일 정보들을 return합니다.
        
        **Request Example**
        
        - EndPoint: [GET] drive/folders/documents
        
        ```jsx
        //QueryParameter : "documents"
        
        //Request Header
        {
        	"x-access-token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJfaWQiOiI1OThkZGI2MzIyYWMxMDExZTA"
        }
        ```
        
        **Response Example**
        
        ```jsx
        {
        	"success": true,
            "error": null,
            "message" : "",
            "root-directory": "/documents",
        	"path-info":[
        		{
                    'filename': "myFolder", 
                    "type": "directory", 
                    "extension": null,
                    "content-type": null,
                    "directory": "/documents/myFolder",
                    "atime":"2022-02-07T09:55:43.724Z",
                    "ctime":"2022-02-07T09:55:43.724Z",
                    "mtime":"2022-02-07T09:55:43.724Z",
                    'birthtime': "2022-02-07T09:55:43.724Z"
                },
                {
                    'filename': "myVideo",
                    "type": "file",
                    "extension": 'mp4',
                    "content-type": 'video',
                    "directory": "/documents/myVideo.mp4",
                    "atime":"2022-02-07T09:55:43.724Z",
                    "ctime":"2022-02-07T09:55:43.724Z",
                    "mtime":"2022-02-07T09:55:43.724Z",
                    'birthtime': "2022-02-07T09:55:43.724Z"
                },
                {
                    'filename': "myPicture",
                    "type": "file",
                    "extension": 'png',
                    "content-type": 'image',
                    "directory": "/documents/myPicture.png",
                    "atime":"2022-02-07T09:55:43.724Z",
                    "ctime":"2022-02-07T09:55:43.724Z",
                    "mtime":"2022-02-07T09:55:43.724Z",
                    'birthtime': "2022-02-07T09:55:43.724Z"
                },
                {
                    'filename': "memo.txt",
                    "type": "file",
                    "extension": 'txt',
                    "content-type": 'text',
                    "directory": "/documents/memo.txt",
                    "atime":"2022-02-07T09:55:43.724Z",
                    "ctime":"2022-02-07T09:55:43.724Z",
                    "mtime":"2022-02-07T09:55:43.724Z",
                    'birthtime': "2022-02-07T09:55:43.724Z"
                }
            ]
        };
        ```
        
    2. 파일 업로드
        - EndPoint: [POST] drive/upload
        - Description:  target-directory경로에 파일을 업로드 합니다.
        
        **Supported Media Types**
        
        <aside>
        📎 multipart/form-data
        
        </aside>
        
        **Request Example**
        
        ```jsx
        //Request Header Parameter
        {
        	"x-access-token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJfaWQiOiI1OThkZGI2MzIyYWMxMDExZTA"
        }
        
        //Form Parameters
        {
        	"fileToUpload": files[]
        }
        ```
        
        **Response Example**
        
        - 성공시
        
        ```jsx
        {
        	"success": true,
        	"message": "files are uploded successfully",
        	"erros": null,
        }
        ```
        
        - 실패시
        
        ```jsx
        {
        	"success": null,
        	"message": "업로드에 실패하였습니다",
        	"erros": true,
        }
        ```